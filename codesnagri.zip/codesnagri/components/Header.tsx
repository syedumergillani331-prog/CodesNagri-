"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "lucide-react";
import { NAV, SITE } from "@/lib/data";
export default function Header() {
  const [open, setOpen] = useState(false);
  const path = usePathname();
  useEffect(() => setOpen(false), [path]);
  useEffect(() => {
    const k = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", k); return () => window.removeEventListener("keydown", k);
  }, []);
  const link = (h: string) => `rounded-lg px-3 py-2 text-sm font-medium transition hover:bg-white/10 ${path === h ? "text-mint" : "text-white"}`;
  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-ink/90 backdrop-blur">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-50 focus:rounded focus:bg-white focus:p-2">Skip to content</a>
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="font-display text-xl font-bold text-white">Codes<span className="text-mint">Nagri</span></Link>
        <nav aria-label="Main" className="hidden items-center gap-1 lg:flex">
          {NAV.map((n) => <Link key={n.href} href={n.href} className={link(n.href)} aria-current={path === n.href ? "page" : undefined}>{n.label}</Link>)}
          <Link href="/contact" className="btn btn-primary ml-2 !py-2">Contact</Link>
        </nav>
        <button className="rounded-lg p-2 text-white lg:hidden" aria-label={open ? "Close menu" : "Open menu"} aria-expanded={open} aria-controls="mobile-nav" onClick={() => setOpen(!open)}>
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav id="mobile-nav" aria-label="Mobile" className="border-t border-white/10 px-4 pb-4 lg:hidden">
          <ul className="flex flex-col py-2">
            {[...NAV, { href: "/contact", label: "Contact" }].map((n) => <li key={n.href}><Link href={n.href} className={`block ${link(n.href)} py-3`} aria-current={path === n.href ? "page" : undefined}>{n.label}</Link></li>)}
          </ul>
        </nav>
      )}
    </header>
  );
}
