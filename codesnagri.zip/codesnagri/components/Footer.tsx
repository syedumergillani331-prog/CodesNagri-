import Link from "next/link";
import { NAV, SITE } from "@/lib/data";
export default function Footer() {
  return (
    <footer className="bg-ink text-slate-300">
      <div className="mx-auto grid max-w-6xl gap-8 px-4 py-12 md:grid-cols-3">
        <div><p className="font-display text-xl font-bold text-white">Codes<span className="text-mint">Nagri</span></p><p className="mt-3 max-w-xs text-sm">{SITE.tagline}</p></div>
        <nav aria-label="Footer"><p className="mb-3 font-semibold text-white">Pages</p><ul className="grid grid-cols-2 gap-2 text-sm">{[...NAV, { href: "/contact", label: "Contact" }].map((n) => <li key={n.href}><Link className="hover:text-mint" href={n.href}>{n.label}</Link></li>)}</ul></nav>
        <div><p className="mb-3 font-semibold text-white">Get in touch</p>
          {SITE.email ? <a className="text-sm hover:text-mint" href={`mailto:${SITE.email}`}>{SITE.email}</a> : <Link className="text-sm hover:text-mint" href="/contact">Send us a message</Link>}</div>
      </div>
      <p className="border-t border-white/10 py-5 text-center text-xs">© {new Date().getFullYear()} {SITE.name}. All rights reserved.</p>
    </footer>
  );
}
