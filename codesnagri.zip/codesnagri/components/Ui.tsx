import * as Icons from "lucide-react";
import type { ReactNode } from "react";
import type { Item } from "@/lib/data";
export function Section({ title, intro, children, tone }: { title?: string; intro?: string; children: ReactNode; tone?: "white" }) {
  return (
    <section className={tone === "white" ? "bg-white" : ""}>
      <div className="mx-auto max-w-6xl px-4 py-16 md:py-20">
        {title && <div className="mb-10 max-w-2xl"><h2 className="font-display text-3xl font-bold md:text-4xl">{title}</h2>{intro && <p className="mt-3 text-lg text-slate-600">{intro}</p>}</div>}
        {children}
      </div>
    </section>
  );
}
export function PageHero({ title, text }: { title: string; text: string }) {
  return (
    <div className="bg-gradient-to-br from-ink via-[#1d2260] to-brand text-white">
      <div className="hero-in mx-auto max-w-6xl px-4 py-16 md:py-24"><h1 className="font-display text-4xl font-bold md:text-5xl">{title}</h1><p className="mt-4 max-w-2xl text-lg text-indigo-100">{text}</p></div>
    </div>
  );
}
export function CardGrid({ items }: { items: Item[] }) {
  return (
    <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((i) => {
        const Icon = (Icons as unknown as Record<string, Icons.LucideIcon>)[i.icon] ?? Icons.Circle;
        return (
          <li key={i.title} className="group rounded-2xl border border-slate-200 bg-white p-6 transition duration-200 hover:-translate-y-1 hover:border-brand/40 hover:shadow-lg">
            <span className="mb-4 inline-flex rounded-xl bg-indigo-50 p-3 text-brand transition group-hover:bg-brand group-hover:text-white"><Icon aria-hidden size={22} /></span>
            {i.tag && <p className="mb-1 text-sm font-medium text-mint">{i.tag}</p>}
            <h3 className="font-display text-xl font-semibold">{i.title}</h3><p className="mt-2 text-slate-600">{i.text}</p>
          </li>
        );
      })}
    </ul>
  );
}
export function Cta({ text = "Tell us what you want to build." }: { text?: string }) {
  return (
    <div className="bg-gradient-to-r from-brand to-mint text-white"><div className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-5 px-4 py-12 md:flex-row md:items-center">
      <p className="font-display text-2xl font-bold">{text}</p><a href="/contact" className="btn btn-primary">Start a conversation</a></div></div>
  );
}
