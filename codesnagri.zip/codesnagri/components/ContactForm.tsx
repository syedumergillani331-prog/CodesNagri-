"use client";
import { useState, type FormEvent } from "react";
import { validate, type Errors, type Form } from "@/lib/validate";
const empty: Form = { name: "", email: "", topic: "", message: "" };
export default function ContactForm() {
  const [f, setF] = useState<Form>(empty);
  const [errors, setErrors] = useState<Errors>({});
  const [status, setStatus] = useState<"idle" | "sending" | "ok" | "fail">("idle");
  const [msg, setMsg] = useState("");
  const set = (k: keyof Form) => (e: { target: { value: string } }) => setF({ ...f, [k]: e.target.value });
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const v = validate(f); setErrors(v);
    if (Object.keys(v).length) return;
    setStatus("sending");
    const website = (new FormData(e.currentTarget).get("website") as string) ?? "";
    try {
      const r = await fetch("/api/contact", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, website }) });
      const d = await r.json();
      if (r.ok) { setStatus("ok"); setF(empty); return; }
      if (d.errors) setErrors(d.errors);
      setMsg(d.error ?? "Please fix the highlighted fields."); setStatus("fail");
    } catch { setMsg("Network problem. Check your connection and try again."); setStatus("fail"); }
  }
  const inp = (k: keyof Form) => `mt-1 w-full rounded-xl border px-4 py-3 ${errors[k] ? "border-red-500" : "border-slate-300"}`;
  const err = (k: keyof Form) => errors[k] && <p id={`${k}-e`} className="mt-1 text-sm text-red-700">{errors[k]}</p>;
  const aria = (k: keyof Form) => ({ "aria-invalid": !!errors[k], "aria-describedby": errors[k] ? `${k}-e` : undefined });
  return (
    <form onSubmit={submit} noValidate className="space-y-5 rounded-2xl border border-slate-200 bg-white p-6">
      <div aria-live="polite">
        {status === "ok" && <p role="status" className="rounded-xl bg-emerald-50 p-4 text-emerald-800">Thanks, your message was sent. We will reply by email.</p>}
        {status === "fail" && <p role="alert" className="rounded-xl bg-red-50 p-4 text-red-800">{msg}</p>}
      </div>
      <label className="block font-medium">Name<input className={inp("name")} value={f.name} onChange={set("name")} autoComplete="name" {...aria("name")} />{err("name")}</label>
      <label className="block font-medium">Email<input type="email" className={inp("email")} value={f.email} onChange={set("email")} autoComplete="email" {...aria("email")} />{err("email")}</label>
      <label className="block font-medium">Topic
        <select className={inp("topic")} value={f.topic} onChange={set("topic")} {...aria("topic")}><option value="">Choose a topic</option><option>Build a project</option><option>IT courses</option><option>Products</option><option>Something else</option></select>{err("topic")}</label>
      <label className="block font-medium">Message<textarea rows={5} className={inp("message")} value={f.message} onChange={set("message")} {...aria("message")} />{err("message")}</label>
      <div className="hidden" aria-hidden><label>Website<input name="website" tabIndex={-1} autoComplete="off" /></label></div>
      <button disabled={status === "sending"} className="btn btn-solid w-full disabled:opacity-60">{status === "sending" ? "Sending…" : "Send message"}</button>
    </form>
  );
}
