export type Form = { name: string; email: string; topic: string; message: string };
export type Errors = Partial<Record<keyof Form, string>>;
export function validate(f: Form): Errors {
  const e: Errors = {};
  if (f.name.trim().length < 2) e.name = "Enter your name (at least 2 characters).";
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(f.email.trim())) e.email = "Enter a valid email address, like name@example.com.";
  if (!f.topic) e.topic = "Choose a topic.";
  if (f.message.trim().length < 20) e.message = "Write at least 20 characters so we can help.";
  if (f.message.length > 3000) e.message = "Keep the message under 3000 characters.";
  return e;
}
