export const SITE = {
  name: "CodesNagri",
  url: process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000",
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL ?? "",
  tagline: "Software, training and technology products, built with care.",
};
export const NAV = [
  { href: "/", label: "Home" }, { href: "/services", label: "Services" },
  { href: "/portfolio", label: "Portfolio" }, { href: "/courses", label: "IT Courses" },
  { href: "/products", label: "Products" }, { href: "/about", label: "About" },
  { href: "/team", label: "Team" },
];
export type Item = { icon: string; title: string; text: string; tag?: string };
export const SERVICES: Item[] = [
  { icon: "Globe", title: "Web development", text: "Fast, accessible websites and web apps built on modern frameworks." },
  { icon: "Smartphone", title: "Mobile apps", text: "iOS and Android apps with a focus on smooth everyday use." },
  { icon: "Brain", title: "AI and ML integration", text: "Add search, classification or automation to the tools you already use." },
  { icon: "Palette", title: "UI/UX design", text: "Clear interfaces, tested with real users before development starts." },
  { icon: "Cloud", title: "Cloud and DevOps", text: "Reliable hosting, deployment pipelines and monitoring." },
  { icon: "LifeBuoy", title: "Maintenance and support", text: "Updates, fixes and improvements after launch." },
];
export const PROJECTS: Item[] = [
  { icon: "ShoppingCart", tag: "Sample concept", title: "Online store", text: "Catalogue, cart and checkout with inventory sync." },
  { icon: "BarChart3", tag: "Sample concept", title: "Business dashboard", text: "Live reports for sales, stock and team activity." },
  { icon: "GraduationCap", tag: "Sample concept", title: "Learning platform", text: "Courses, progress tracking and certificates." },
];
export const COURSES: Item[] = [
  { icon: "Code2", title: "Web development", text: "HTML, CSS, JavaScript, React and Next.js, taught through projects.", tag: "Beginner to intermediate" },
  { icon: "Terminal", title: "Python programming", text: "Fundamentals, automation and an introduction to data work.", tag: "Beginner" },
  { icon: "Brain", title: "Intro to AI and ML", text: "Core ideas and hands-on models using common libraries.", tag: "Intermediate" },
  { icon: "Palette", title: "UI/UX basics", text: "Layout, typography, prototyping and usability testing.", tag: "Beginner" },
];
export const PRODUCTS: Item[] = [
  { icon: "Package", title: "Business management software", text: "Invoicing, inventory and reporting in one place.", tag: "Planned" },
  { icon: "Cpu", title: "Computer hardware and accessories", text: "Peripherals and components, with setup advice.", tag: "Planned" },
  { icon: "Boxes", title: "Ready-made website templates", text: "Starter sites you can launch and customise.", tag: "Planned" },
];
export const TEAM = [
  { role: "Founder and engineering lead", note: "Add name and bio" },
  { role: "Frontend developer", note: "Add name and bio" },
  { role: "Backend developer", note: "Add name and bio" },
  { role: "UI/UX designer", note: "Add name and bio" },
  { role: "Course instructor", note: "Add name and bio" },
  { role: "Project coordinator", note: "Add name and bio" },
];
export const VALUES: Item[] = [
  { icon: "MessageSquare", title: "Plain communication", text: "Clear scope, honest timelines and regular updates." },
  { icon: "ShieldCheck", title: "Quality by default", text: "Accessible, secure and tested before it ships." },
  { icon: "Sprout", title: "Teach as we build", text: "We share what we learn through our courses." },
];
export const FAQS = [
  { q: "What kinds of projects do you take on?", a: "Websites, web and mobile apps, AI integrations and ongoing support. Send us a brief and we will tell you honestly if it is a fit." },
  { q: "How does pricing work?", a: "We scope each project first, then quote a fixed price or a monthly rate. Use the contact form to start." },
  { q: "Do you offer courses for complete beginners?", a: "Yes. Our beginner tracks assume no prior experience." },
  { q: "Can you maintain a site someone else built?", a: "Usually, yes. We review the code first and then agree on support." },
  { q: "How do I get started?", a: "Send a message from the contact page with your goals and timeline." },
];
// Add real, permitted client reviews here. The section stays hidden while empty.
export const TESTIMONIALS: { quote: string; name: string; role: string }[] = [];
