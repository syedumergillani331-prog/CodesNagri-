import type { Metadata } from "next";
import { PageHero, Section, CardGrid, Cta } from "@/components/Ui";
import { PRODUCTS } from "@/lib/data";
export const metadata: Metadata = { title: "Products", description: "Software and hardware products we are preparing to offer.", alternates: { canonical: "/products" } };
export default function Page() {
  return (<><PageHero title="Products" text="Software and hardware products we are preparing to offer." /><Section><CardGrid items={PRODUCTS} /></Section><Cta /></>);
}
