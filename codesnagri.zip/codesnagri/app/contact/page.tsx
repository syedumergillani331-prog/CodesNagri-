import type { Metadata } from "next";
import ContactForm from "@/components/ContactForm";
import { PageHero, Section } from "@/components/Ui";
import { SITE } from "@/lib/data";
export const metadata: Metadata = { title: "Contact", description: "Tell CodesNagri about your project or course interest.", alternates: { canonical: "/contact" } };
export default function Page() {
  return (<><PageHero title="Contact us" text="Share your goals and timeline. We will reply by email." />
    <Section><div className="mx-auto max-w-2xl"><ContactForm />{SITE.email && <p className="mt-6">Or email <a className="text-brand underline" href={`mailto:${SITE.email}`}>{SITE.email}</a>.</p>}</div></Section></>);
}
