import Link from "next/link";
import { Section, CardGrid, Cta } from "@/components/Ui";
import Faq from "@/components/Faq";
import { SERVICES, PROJECTS, VALUES, TESTIMONIALS } from "@/lib/data";
export default function Home() {
  return (<>
    <div className="overflow-hidden bg-gradient-to-br from-ink via-[#1d2260] to-brand text-white">
      <div className="mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:py-28 lg:grid-cols-2">
        <div className="hero-in">
          <p className="mb-4 inline-block rounded-full bg-white/10 px-4 py-1 text-sm">Software house · IT training · Technology products</p>
          <h1 className="font-display text-4xl font-bold leading-tight md:text-6xl">Software that works as hard as your business.</h1>
          <p className="mt-5 max-w-xl text-lg text-indigo-100">We design and build websites, apps and AI tools, and we teach the skills behind them.</p>
          <div className="mt-8 flex flex-wrap gap-3"><Link href="/contact" className="btn btn-primary">Start a project</Link><Link href="/courses" className="btn btn-ghost">Explore IT courses</Link></div>
        </div>
        <div aria-hidden className="rounded-2xl border border-white/15 bg-ink/70 p-5 font-mono text-sm shadow-2xl">
          <div className="mb-4 flex gap-2"><i className="h-3 w-3 rounded-full bg-red-400" /><i className="h-3 w-3 rounded-full bg-yellow-300" /><i className="h-3 w-3 rounded-full bg-mint" /></div>
          <p><span className="text-mint">const</span> project = <span className="text-indigo-300">await</span> build({"{"}</p>
          <p className="pl-4">goal: <span className="text-amber-200">"your idea"</span>,</p>
          <p className="pl-4">quality: <span className="text-amber-200">"tested"</span>,</p>
          <p>{"}"});</p>
        </div>
      </div>
    </div>
    <Section title="What we do" intro="From first sketch to launch and support."><CardGrid items={SERVICES} /><Link href="/services" className="btn btn-solid mt-8">All services</Link></Section>
    <Section tone="white" title="Featured work" intro="Sample concepts that show our approach. Real client projects will be added with permission."><CardGrid items={PROJECTS} /></Section>
    <Section title="How we work"><CardGrid items={VALUES} /></Section>
    {TESTIMONIALS.length > 0 && <Section tone="white" title="Client feedback"><ul className="grid gap-5 md:grid-cols-2">{TESTIMONIALS.map((t) => <li key={t.name} className="rounded-2xl border p-6"><blockquote>“{t.quote}”</blockquote><p className="mt-3 font-semibold">{t.name}, {t.role}</p></li>)}</ul></Section>}
    <Section tone="white" title="Frequently asked questions"><Faq /></Section>
    <Cta />
  </>);
}
