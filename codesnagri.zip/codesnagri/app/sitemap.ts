import type { MetadataRoute } from "next";
import { SITE } from "@/lib/data";
export default function sitemap(): MetadataRoute.Sitemap {
  return ["", "/services", "/about", "/team", "/portfolio", "/courses", "/products", "/contact"].map((p) => ({ url: SITE.url + p, lastModified: new Date() }));
}
