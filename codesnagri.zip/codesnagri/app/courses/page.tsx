import type { Metadata } from "next";
import { PageHero, Section, CardGrid, Cta } from "@/components/Ui";
import { COURSES } from "@/lib/data";
export const metadata: Metadata = { title: "IT Courses", description: "Project-based IT courses for beginners and career changers.", alternates: { canonical: "/courses" } };
export default function Page() {
  return (<><PageHero title="IT Courses" text="Project-based IT courses for beginners and career changers." /><Section><CardGrid items={COURSES} /></Section><Cta /></>);
}
