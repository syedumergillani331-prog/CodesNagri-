import { NextResponse } from "next/server";
import { validate, type Form } from "@/lib/validate";
export async function POST(req: Request) {
  let body: Form & { website?: string };
  try { body = await req.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  if (body.website) return NextResponse.json({ ok: true }); // honeypot
  const f = { name: String(body.name ?? ""), email: String(body.email ?? ""), topic: String(body.topic ?? ""), message: String(body.message ?? "") };
  const errors = validate(f);
  if (Object.keys(errors).length) return NextResponse.json({ errors }, { status: 422 });
  const hook = process.env.CONTACT_WEBHOOK_URL;
  if (!hook) return NextResponse.json({ error: "Messages are not being received yet. The site owner must set CONTACT_WEBHOOK_URL." }, { status: 503 });
  try {
    const r = await fetch(hook, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ...f, text: `New message from ${f.name} (${f.email}) about ${f.topic}: ${f.message}` }) });
    if (!r.ok) throw new Error();
    return NextResponse.json({ ok: true });
  } catch { return NextResponse.json({ error: "We could not send your message. Please try again shortly." }, { status: 502 }); }
}
